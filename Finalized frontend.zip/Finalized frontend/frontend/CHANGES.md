# What changed in this pass

## Backend (built on the sprint-4 branch — auth + appointments + billing + reports)

**New: Animal Records module** (the piece that was missing)
- `owners` table — pet owners/clients. `userId` links to a portal login when the
  owner has one; nullable so staff can register a walk-in owner before they sign up.
- `patients` table (kept this name since `invoices.patient_id` and the frontend's
  "Patients" page already used it) expanded from `{id, name, species}` into a real
  animal record: `ownerId`, `breed`, `sex`, `dateOfBirth`, `weightKg`, `color`,
  `microchipId`, `allergies`, `medicalNotes`, `status`.
- `src/controllers/ownerController.ts` + `src/routes/ownerRoutes.ts` — full CRUD.
- `src/controllers/patientController.ts` + `src/routes/patientRoutes.ts` — full CRUD,
  search via `?q=`.
- Access rules: staff (`vet`/`receptionist`/`admin`) see and manage everything.
  A `client` only sees/manages the owner + animals linked to their own account.
- Signup now auto-creates an `owners` row for new `client` accounts, so the
  animal-records module plugs straight into auth without an extra step.

**Appointments** — `appointments.patient_id` now optionally links to a real
animal record. Pass `patientId` when booking and `petName`/`petType` are pulled
from the record automatically; the old free-text fields still work as a
fallback for walk-ins.

**Billing** — added `invoiceItems` (line-item breakdown, matching what the
frontend billing page already expected) and:
- `POST /api/billing/invoices` — staff creates an invoice with services.
- `GET /api/billing/invoices` / `GET /api/billing/invoices/:id` — listing was
  completely missing before (STK push could only create invoices, nothing
  could read them back). Also fixed a hardcoded `patientId: 1` in the STK
  push handler.

**Reports** — `/api/reports/daily` had no auth at all before; it's now
staff-only like the rest of the admin surface.

Run `npx drizzle-kit push` after pulling this to apply the schema changes to
your database (there's no separate migration file yet — the sprint-4 branch
wasn't using migrations either, so this matches the existing setup).

## Frontend (vetcare-manager — same visual design, now wired to the real API)

- `src/api/client.js` — small fetch wrapper, reads `VITE_API_URL` from `.env`
  (copy `.env.example`), attaches the JWT automatically.
- `src/context/AuthContext.jsx` + `pages/Login.jsx` + `pages/Signup.jsx` — there
  was no login screen at all before; added one matching the existing style.
- Every page (`Patients`, `Owners`, `Appointments`, `Billing`, `Dashboard`,
  `Search`) now fetches from the API instead of `seedData.js` and shows
  role-appropriate actions (e.g. clients can't edit medical notes or delete
  records; only staff can).
- `Patients` (Animal Records) got a full rebuild of its form to match the new
  schema: owner picker, species/breed/sex/DOB/weight/color/microchip/allergies,
  medical notes gated to staff.
- `Billing` now has an actual invoice list + a "New Invoice" flow for staff
  with a line-item builder, since that didn't exist before either.

Nothing in `components/ui.jsx`, `utils/styles.js`, or `index.css` changed —
same colors, same table/button look, same responsive breakpoints.

## Known gaps / good next tasks for whoever's free
- No dedicated staff directory endpoint yet, so appointments don't have a
  "assign vet" dropdown in the UI (the `staffId` field on the backend is
  ready for it).
- No migrations folder — `drizzle-kit push` works for now but you'll want
  proper migrations before this touches a shared/production database.
- Owner deletion is blocked while they have linked animals (409), which is
  intentional, but there's no UI flow yet for reassigning an animal to a
  different owner.

---

# Round 2 — fixes from live testing

- **Client dashboard no longer shows an "Owners" card** — that stat/nav item
  is now staff-only (`Owners` nav item hidden entirely for `client` role).
- **Can't book appointments in the past anymore.** Enforced in both places:
  - Frontend: date picker has a `min` of today, and submit is blocked with an
    inline error if the combined date+time has already passed.
  - Backend: `POST /api/appointments` rejects any `appointmentDate` in the
    past with a 400, so this can't be bypassed by calling the API directly.
- **Price transparency at booking time.** The appointment form now shows a
  non-binding "typical price guide" (consultation, vaccination, deworming,
  etc.) so clients have a rough idea of cost before booking. The actual
  invoice is still created by staff after the visit, since real cost depends
  on what the vet finds — this is intentionally an estimate, not a quote.
- **Staff accounts + a real vet-facing dashboard.**
  - New admin-only endpoints: `GET /api/auth/staff` and `POST /api/auth/staff`
    to list/create vet, receptionist, and admin accounts — no more hand-typed
    curl commands after your first admin exists.
  - New `GET /api/users/vets` endpoint (any authenticated user) powers a
    "Preferred Vet" dropdown on the booking form.
  - New "Staff" page in the sidebar, visible to `admin` only, with an
    "Add Staff Account" form.
  - **The Dashboard is now role-specific.** A `vet` logging in sees: total
    animal records, their appointment count for today, a list of their own
    upcoming appointments with quick Confirm/Complete actions, and a separate
    "Unassigned appointments" list they can claim with one click. Receptionist/
    admin keep the practice-wide overview (owners, animals, next appointments
    across all vets). Clients keep their personal overview.

### Bootstrapping your first admin account
Public signup (the Sign Up screen) only ever creates `client` accounts, by
design — that's the walk-in/pet-owner path. Since staff accounts are now
created from the in-app Staff page, you need exactly **one** admin account to
get started, created directly via the API before any staff exist:

```powershell
Invoke-RestMethod -Uri "http://localhost:3000/api/auth/signup" -Method Post -ContentType "application/json" -Body '{"firstName":"Jane","lastName":"Admin","email":"admin@example.com","password":"password123","role":"admin"}'
```

Log in as that admin in the UI, go to **Staff → Add Staff Account**, and
create your vet/receptionist accounts from there.

---

# Round 3 — signup now lets you pick your role

Turns out gating vet/receptionist/admin creation behind an admin-only Staff
page was more friction than you wanted. The backend already accepted a
`role` field on signup — I'd just locked the frontend Signup form to always
send `"client"`. That's removed now: the Signup screen has an "I am a..."
dropdown (Pet Owner / Veterinarian / Receptionist / Admin), and whichever
role you pick is what you log in as immediately after.

**Heads up:** this means self-service signup can make anyone an admin. Fine
for a class/group project, but if this ever becomes a real production app,
put staff-role signup behind an invite code or admin approval — the
admin-only "Staff" page from Round 2 is still in the code if you want to
switch back to that model later.

---

# Round 4 — fixed price catalog + real payment flow

**Fixed price list (no more typing prices by hand)**
- New `src/data/serviceCatalog.ts` on the backend — a flat, editable list of
  common clinic services with standard prices (consultations, vaccines,
  deworming, wound care, surgery, lab work, grooming, boarding, etc).
- `GET /api/billing/services` exposes it to the frontend.
- The **invoice builder** (Billing → New Invoice) now has a dropdown per line
  item that auto-fills the service name and price from the catalog — staff
  can still edit the price or type a fully custom item if something isn't
  on the list.
- The **appointment booking form**'s price guide now pulls from this same
  catalog (grouped by category) instead of a separate hardcoded range list,
  so clients and staff always see the same numbers.
- To change a price clinic-wide, edit `serviceCatalog.ts` and restart the
  backend — no database change needed.

**Real payment flow (this was actually missing before — the STK push
endpoint existed but nothing in the UI ever called it)**
- Invoice detail page now has a **"Take Payment"** panel, staff-only, shown
  while an invoice is unpaid:
  - Enter the client's M-Pesa number and click **"Send M-Pesa Prompt"** —
    this is the receptionist/staff triggering the payment request on the
    client's behalf, not the client doing anything themselves in the app.
    The invoice flips to PAID automatically via the existing callback once
    they confirm on their phone.
  - Or click **"Mark Paid — Cash"** / **"Mark Paid — Bank Transfer"** to
    record payment taken outside M-Pesa. New endpoint:
    `PATCH /api/billing/invoices/:id/pay` with `{ "method": "cash" }`.
- Added a `payment_method` column to `invoices` (`mpesa` | `cash` |
  `bank_transfer` | `other`), shown on the invoice once paid.

### ⚠️ Schema change — needs another push
This round added one column. Easiest way to apply it: run this directly in
Neon's SQL Editor (same place you ran the earlier migration):

```sql
ALTER TABLE "invoices" ADD COLUMN "payment_method" text;
```

Or re-run `npx drizzle-kit generate` + apply the new migration file the same
way as before if you'd rather keep using that flow.

---

# Round 5 — M-Pesa 500 error fixed with a mock/demo mode

**Why it was failing:** the STK push endpoint depends on real Safaricom
Daraja sandbox credentials (`DARAJA_CONSUMER_KEY`, `DARAJA_CONSUMER_SECRET`,
`DARAJA_SHORTCODE`, `DARAJA_PASSKEY`). If `.env` still has the placeholder
values from the original setup instructions, Safaricom's API rejects the
request and the old code turned that into a generic 500 with no detail.
This was true of the *original* sprint-4 code too — nothing about my
earlier changes caused this, swapping back to the old controller would have
failed identically. Also found and fixed a second, separate bug: the
callback URL was hardcoded to a personal ngrok tunnel
(`perfusive-overgenerous-deane.ngrok-free.dev`) from whoever built the
original sprint, which is almost certainly not running anymore — so even a
successful push would never report back.

**What changed:**
- `DARAJA_CALLBACK_URL` is now a proper env var instead of a hardcoded
  personal tunnel — set it once you have your own ngrok/public URL.
- Real Safaricom errors are now returned in the response (`details` field)
  instead of a generic message, so if you *do* have real credentials and it
  still fails, you'll see exactly why (bad shortcode, invalid phone format,
  expired token, etc).
- **New: mock/demo mode.** If Daraja credentials are missing or still look
  like placeholders (start with `your-`), or `MPESA_MOCK=true` is set,
  `POST /api/billing/stkpush` no longer calls Safaricom at all — it
  simulates a successful payment immediately (fake receipt number, invoice
  marked PAID) so the flow is fully demoable without a live sandbox
  connection or public callback URL. The UI shows a clear "Demo mode"
  message when this happens, so nobody mistakes it for a real payment.

### To actually send real STK prompts
You need a **real Safaricom Daraja sandbox account** (existing placeholder
values will never work, mock mode will always be used instead):
1. Register at https://developer.safaricom.co.ke and create an app to get
   a real `DARAJA_CONSUMER_KEY` / `DARAJA_CONSUMER_SECRET`.
2. For sandbox testing, `DARAJA_SHORTCODE=174379` and
   `DARAJA_PASSKEY=bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919`
   are Safaricom's own published sandbox test values (same for every
   developer, documented on their portal).
3. **Sandbox STK pushes only work for Safaricom's designated test phone
   numbers** (e.g. `254708374149`), not arbitrary real numbers — this is a
   Safaricom sandbox limitation, not a bug in this app.
4. You'll also need a real public callback URL (ngrok or similar) reachable
   by Safaricom, set as `DARAJA_CALLBACK_URL` — without it, pushes will send
   but invoices will stay PENDING forever since Safaricom can't reach you to
   confirm payment.

---

# Round 6 — session/logout hardening (shared-computer gap)

Clarifying the actual scope of the "does someone else see my dashboard"
concern: sessions are stored in the browser's `localStorage`, which is
sandboxed per browser/device — **a teammate on their own computer never
sees your session**, full stop. The real (and normal-for-any-web-app) risk
is a **shared computer, same browser** where someone doesn't log out.

Hardened that case two ways:
- On app load, a saved token's expiry is checked client-side — an expired
  session (tokens last 8h) is cleared automatically instead of quietly
  showing stale state.
- Any API call that comes back `401` (expired/invalid/tampered token) now
  triggers an immediate logout everywhere in the app, instead of just
  failing that one request silently.

**Still true, and this is just how "remember me" sessions work everywhere:**
if someone walks away from a shared computer mid-session without clicking
Logout, the next person on that same browser has up to 8 hours before the
token expires. If you want stronger protection on shared/lab computers,
two options to consider (not implemented, since they trade off
convenience):
- Shorten the JWT expiry in `authRoutes.ts` (currently `expiresIn: '8h'`).
- Switch from `localStorage` to `sessionStorage` for the token — this
  would log everyone out automatically when the browser tab/window closes,
  which is safer on shared machines but means personal devices need a
  fresh login every session too.

---

# Round 7 — merged in a teammate's Medical Reports module

You uploaded a `vetSys-master` zip that turned out to branch off the
**original, untouched sprint-4 code** (not anything I'd built on top of) —
so it was missing all the owners/patients/billing/role work from the
earlier rounds, but it added one genuinely new, useful piece: a Medical
Reports module (symptoms/diagnosis/treatment plan/prescriptions per
appointment). I merged that in properly rather than copy-pasting it —
converted it to match your current schema and conventions rather than
sitting alongside them as a separate style.

**What changed vs. their version:**
- Switched the report table's primary key from `uuid` to `serial`, to match
  every other table in your schema (no new Postgres extension needed).
- Added a `patientId` link on the report itself (copied from the
  appointment at creation time), so a report ties directly to the real
  animal record — their version only linked to the appointment.
- Rewrote the controller in Drizzle (matching `patientController.ts` /
  `ownerController.ts`) instead of raw SQL, and reused your existing
  `STAFF_ROLES` / ownership-check patterns instead of duplicating them.
- **Kept `/api/reports/daily`** (the staff-only revenue report from the
  billing sprint) — their branch had silently replaced the whole
  `reportRoutes.ts` file, which would have deleted that endpoint. Medical
  reports now live at a separate `/api/medical-reports` path instead, so
  nothing collides.
- Added one thing they didn't have: `GET /api/medical-reports/patient/:id`
  — full visit history for one animal, not just per-appointment lookup.
  This now powers a **Medical History** section shown right on the animal
  record page.

**New endpoints:**
| Method | Route | Who | What |
|---|---|---|---|
| `POST` | `/api/medical-reports` | vet, admin | Write up a report for an appointment (symptoms + diagnosis required). Marks the appointment `completed` automatically. One report per appointment. |
| `GET` | `/api/medical-reports/appointment/:appointmentId` | authenticated | Fetch the report for one appointment. Clients: only their own. |
| `GET` | `/api/medical-reports/patient/:patientId` | authenticated | Full report history for one animal, newest first. Clients: only their own animal. |
| `PATCH` | `/api/medical-reports/:id` | vet, admin | Edit an existing report. |

**Frontend:**
- Appointments page: vets/admins get a **"Write Report"** link on any
  appointment that isn't already completed or cancelled; everyone gets
  **"View Report"** once an appointment is completed.
- New report screen handles both writing and viewing, with an Edit option
  for vets/admins.
- Animal Records page now shows a **Medical History** timeline (diagnosis,
  treatment, prescriptions, which vet, when) right on the record — visible
  to staff and to the animal's own owner.

### Schema change — needs another push
One new table this round. Run in Neon's SQL Editor, or regenerate/apply a
migration the same way as before:

```sql
CREATE TABLE "medical_reports" (
  "id" serial PRIMARY KEY,
  "appointment_id" integer NOT NULL UNIQUE REFERENCES "appointments"("id"),
  "patient_id" integer REFERENCES "patients"("id"),
  "symptoms" text NOT NULL,
  "diagnosis" text NOT NULL,
  "treatment_plan" text,
  "prescriptions" text,
  "vet_id" integer NOT NULL REFERENCES "users"("id"),
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);
```
