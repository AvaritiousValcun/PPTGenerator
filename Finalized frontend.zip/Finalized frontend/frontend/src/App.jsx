import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";
import Dashboard from "./pages/Dashboard";
import Patients from "./pages/Patients";
import Owners from "./pages/Owners";
import Appointments from "./pages/Appointments";
import Billing from "./pages/Billing";
import Search from "./pages/Search";
import Staff from "./pages/Staff";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import { useAuth } from "./context/AuthContext";

export default function App() {
  const { user } = useAuth();
  const [authScreen, setAuthScreen] = useState("login");

  const [page, setPage] = useState("Dashboard");
  const [focusRecord, setFocusRecord] = useState(null);

  // Always land on the Dashboard for a fresh sign-in — without this, a
  // user who was on e.g. Billing, logged out, then logged back in would
  // land right back on Billing instead, since App never actually unmounts.
  useEffect(() => {
    if (user) {
      setPage("Dashboard");
      setFocusRecord(null);
    }
  }, [user?.id]);

  function goTo(pageName, record) {
    setFocusRecord(record || null);
    setPage(pageName);
  }

  if (!user) {
    return authScreen === "login" ? (
      <Login goToSignup={() => setAuthScreen("signup")} />
    ) : (
      <Signup goToLogin={() => setAuthScreen("login")} />
    );
  }

  return (
    <div className="app-shell">
      <Sidebar page={page} setPage={goTo} />
      <div className="main-column">
        <TopBar />
        <div className="page-content">
          {page === "Dashboard" && <Dashboard goTo={goTo} />}
          {page === "Patients" && (
            <Patients focusRecord={focusRecord} clearFocus={() => setFocusRecord(null)} />
          )}
          {page === "Owners" && (
            <Owners focusRecord={focusRecord} clearFocus={() => setFocusRecord(null)} />
          )}
          {page === "Appointments" && (
            <Appointments focusRecord={focusRecord} clearFocus={() => setFocusRecord(null)} />
          )}
          {page === "Billing" && <Billing focusRecord={focusRecord} />}
          {page === "Search" && <Search goTo={goTo} />}
          {page === "Staff" && <Staff />}
        </div>
      </div>
    </div>
  );
}
