// Thin fetch wrapper for the VetSys backend. Base URL comes from Vite env
// (set VITE_API_URL in a .env file); falls back to localhost for dev.
const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

function getToken() {
  return localStorage.getItem("vetsys_token");
}

// Set by AuthContext so a 401 from any request can force an immediate
// logout — e.g. token expired, or was revoked/tampered with. Without this,
// a stale token would just keep failing requests silently while still
// showing whatever page was last on screen.
let onUnauthorized = () => {};
export function setUnauthorizedHandler(fn) {
  onUnauthorized = fn;
}

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try {
    data = await res.json();
  } catch {
    // no JSON body
  }

  if (!res.ok) {
    if (res.status === 401 && auth) {
      onUnauthorized();
    }
    const message = (data && data.message) || `Request failed with status ${res.status}`;
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }

  return data;
}

export const api = {
  get: (path) => request(path, { method: "GET" }),
  post: (path, body) => request(path, { method: "POST", body }),
  patch: (path, body) => request(path, { method: "PATCH", body }),
  del: (path) => request(path, { method: "DELETE" }),

  // Auth endpoints don't send a token
  login: (email, password) => request("/api/auth/login", { method: "POST", body: { email, password }, auth: false }),
  signup: (payload) => request("/api/auth/signup", { method: "POST", body: payload, auth: false }),
};
