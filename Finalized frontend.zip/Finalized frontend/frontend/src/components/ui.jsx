import React from "react";

export function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

export function Link({ children, onClick }) {
  return (
    <span onClick={onClick} style={{ color: "#0d9488", cursor: "pointer", textDecoration: "none" }}>
      {children}
    </span>
  );
}

export function Th({ children }) {
  return <th style={{ textAlign: "left", padding: "10px 12px", background: "#e2e8f0", fontSize: 14 }}>{children}</th>;
}

export function Td({ children }) {
  return <td style={{ padding: "10px 12px", fontSize: 14, borderBottom: "1px solid #f1f5f9" }}>{children}</td>;
}

export function Loading({ label = "Loading..." }) {
  return <p style={{ color: "#64748b", padding: "24px 0" }}>{label}</p>;
}

export function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#b91c1c", borderRadius: 4, padding: "10px 14px", fontSize: 14, marginBottom: 16 }}>
      {message}
    </div>
  );
}
