import React from "react";
import { useAuth } from "../context/AuthContext";

export default function TopBar() {
  const { user, logout } = useAuth();

  return (
    <div className="topbar" style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", padding: "0 24px", gap: 16 }}>
      {user && (
        <>
          <span style={{ color: "#e2e8f0", fontSize: 14 }}>
            {user.firstName} {user.lastName}
            <span style={{ color: "#94a3b8", marginLeft: 6, fontSize: 12, textTransform: "capitalize" }}>({user.role})</span>
          </span>
          <span
            onClick={logout}
            style={{ color: "#5eead4", fontSize: 14, cursor: "pointer", fontWeight: 600 }}
          >
            Log out
          </span>
        </>
      )}
    </div>
  );
}
