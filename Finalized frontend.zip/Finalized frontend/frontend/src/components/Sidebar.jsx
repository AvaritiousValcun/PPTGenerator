import React from "react";
import { NAV_ITEMS } from "../data/seedData";
import { useAuth } from "../context/AuthContext";

const STAFF_ROLES = ["vet", "receptionist", "admin"];

export default function Sidebar({ page, setPage }) {
  const { user } = useAuth();
  const isStaff = STAFF_ROLES.includes(user?.role);
  const isAdmin = user?.role === "admin";

  // Clients manage their own contact details when adding/viewing an animal,
  // so a standalone "Owners" directory is only useful for staff.
  let items = isStaff ? NAV_ITEMS : NAV_ITEMS.filter((item) => item !== "Owners");
  if (isAdmin) items = [...items, "Staff"];

  return (
    <div className="sidebar">
      <div className="sidebar-brand">
        <span style={{ color: "#fff", fontWeight: 700, fontSize: 18, letterSpacing: 0.3 }}>VetCare Manager</span>
      </div>
      <nav className="sidebar-nav">
        {items.map((item) => (
          <div
            key={item}
            onClick={() => setPage(item)}
            className={"sidebar-item" + (item === page ? " active" : "")}
          >
            {item}
          </div>
        ))}
      </nav>
    </div>
  );
}
