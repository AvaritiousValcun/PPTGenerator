import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { api, setUnauthorizedHandler } from "../api/client";

const AuthContext = createContext(null);

// Reads the (unsigned, client-side) expiry out of a JWT so we can tell if a
// saved session has already expired before even making a request. This is
// just a UX check — the backend independently rejects expired tokens too.
function isExpired(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (!payload.exp) return false;
    return Date.now() >= payload.exp * 1000;
  } catch {
    return true;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem("vetsys_token");
    const raw = localStorage.getItem("vetsys_user");
    if (!token || !raw || isExpired(token)) {
      localStorage.removeItem("vetsys_token");
      localStorage.removeItem("vetsys_user");
      return null;
    }
    return JSON.parse(raw);
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const logout = useCallback(() => {
    localStorage.removeItem("vetsys_token");
    localStorage.removeItem("vetsys_user");
    setUser(null);
  }, []);

  // If any API call ever comes back 401 (expired or invalid token), sign
  // out immediately rather than leaving a half-authenticated screen up.
  useEffect(() => {
    setUnauthorizedHandler(logout);
  }, [logout]);

  const login = useCallback(async (email, password) => {
    setLoading(true);
    setError("");
    try {
      const data = await api.login(email, password);
      localStorage.setItem("vetsys_token", data.token);
      localStorage.setItem("vetsys_user", JSON.stringify(data.user));
      setUser(data.user);
      return true;
    } catch (e) {
      setError(e.message || "Login failed.");
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const signup = useCallback(async (payload) => {
    setLoading(true);
    setError("");
    try {
      await api.signup(payload);
      // Auto-login right after signup for a smooth flow
      return await login(payload.email, payload.password);
    } catch (e) {
      setError(e.message || "Signup failed.");
      return false;
    } finally {
      setLoading(false);
    }
  }, [login]);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, error, setError, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
