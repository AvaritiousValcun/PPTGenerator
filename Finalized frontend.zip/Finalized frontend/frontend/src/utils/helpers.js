export function money(n) {
  return "KES " + Number(n || 0).toLocaleString();
}

export function invoiceTotal(invoice) {
  return (invoice.items || []).reduce((sum, item) => sum + Number(item.cost || 0), 0);
}

// Format an ISO date string the way the rest of the UI expects, e.g. "Jul 21, 2026"
export function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function formatTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return "";
  return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

export function calcAge(dateOfBirth) {
  if (!dateOfBirth) return "Unknown";
  const dob = new Date(dateOfBirth);
  if (isNaN(dob)) return "Unknown";
  const diffMs = Date.now() - dob.getTime();
  const years = diffMs / (1000 * 60 * 60 * 24 * 365.25);
  if (years < 1) return `${Math.max(1, Math.round(years * 12))} mo`;
  return `${Math.floor(years)} yr`;
}
