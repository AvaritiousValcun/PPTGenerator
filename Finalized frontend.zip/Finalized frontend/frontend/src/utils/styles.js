// shared look-and-feel so every page doesn't reinvent the same table/button styles

export const tableStyle = { width: "100%", borderCollapse: "collapse", border: "1px solid #e2e8f0" };

export const inputStyle = {
  padding: "9px 12px",
  border: "1px solid #cbd5e1",
  borderRadius: 4,
  fontSize: 14,
  width: "100%",
  boxSizing: "border-box",
};

export const primaryBtn = {
  background: "#0d9488",
  color: "#fff",
  border: "none",
  padding: "10px 18px",
  borderRadius: 4,
  fontSize: 14,
  fontWeight: 600,
  cursor: "pointer",
};

export const secondaryBtn = {
  background: "#64748b",
  color: "#fff",
  border: "none",
  padding: "10px 18px",
  borderRadius: 4,
  fontSize: 14,
  fontWeight: 600,
  cursor: "pointer",
  marginLeft: 8,
};

export function rowStyle(i) {
  return { background: i % 2 === 1 ? "#f8fafc" : "#fff" };
}
