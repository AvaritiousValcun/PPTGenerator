import React, { useState } from "react";
import { Field, ErrorBanner } from "../components/ui";
import { inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";

export default function OwnerForm({ initial, isStaff, onCancel, onSave }) {
  const [fullName, setFullName] = useState(initial?.fullName || "");
  const [phone, setPhone] = useState(initial?.phone || "");
  const [email, setEmail] = useState(initial?.email || "");
  const [address, setAddress] = useState(initial?.address || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setSaving(true);
    setError("");
    try {
      await onSave({ fullName, phone, email, address }, initial?.id);
    } catch (e) {
      setError(e.message || "Failed to save owner.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>{initial ? "Edit Owner" : "Add Owner"}</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Enter the owner's contact details below</p>
      <ErrorBanner message={error} />

      <div className="form-grid">
        <Field label="Full Name"><input style={inputStyle} value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="e.g. Mr. Otieno" /></Field>
        <Field label="Phone Number"><input style={inputStyle} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. +254 712 345 678" /></Field>
        <Field label="Email Address"><input style={inputStyle} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="e.g. otieno@gmail.com" /></Field>
        <Field label="Address"><input style={inputStyle} value={address} onChange={(e) => setAddress(e.target.value)} placeholder="e.g. Ngong Road, Nairobi" /></Field>
      </div>

      {initial?.animals && (
        <Field label="Linked Animals">
          {initial.animals.length === 0 ? (
            <p style={{ color: "#94a3b8", fontSize: 14 }}>No animals linked to this owner yet.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 20, fontSize: 14, color: "#334155" }}>
              {initial.animals.map((a) => (
                <li key={a.id}>{a.name} — {a.species}{a.breed ? `, ${a.breed}` : ""}</li>
              ))}
            </ul>
          )}
        </Field>
      )}

      <div style={{ marginTop: 16 }}>
        <button style={primaryBtn} onClick={submit} disabled={saving || !fullName}>{saving ? "Saving..." : "Save Owner"}</button>
        <button style={secondaryBtn} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
