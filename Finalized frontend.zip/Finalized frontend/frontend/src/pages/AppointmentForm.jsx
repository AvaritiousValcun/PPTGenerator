import React, { useEffect, useState } from "react";
import { Field, ErrorBanner } from "../components/ui";
import { inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";
import { money } from "../utils/helpers";
import { api } from "../api/client";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// Groups the flat service catalog into { category: [service, ...] } for
// a tidier price-guide display.
function groupByCategory(services) {
  const groups = {};
  for (const s of services) {
    if (!groups[s.category]) groups[s.category] = [];
    groups[s.category].push(s);
  }
  return groups;
}

export default function AppointmentForm({ patients, onCancel, onSave }) {
  const [patientId, setPatientId] = useState(patients[0]?.id || "");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [staffId, setStaffId] = useState("");
  const [vets, setVets] = useState([]);
  const [services, setServices] = useState([]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get("/api/users/vets").then((res) => setVets(res.vets || [])).catch(() => {});
    api.get("/api/billing/services").then((res) => setServices(res.services || [])).catch(() => {});
  }, []);

  async function submit() {
    setError("");
    if (!patientId || !date || !time || !reason) {
      setError("Please fill in the animal, date, time, and reason for the visit.");
      return;
    }

    const appointmentDate = new Date(`${date}T${time}`);
    if (appointmentDate.getTime() < Date.now()) {
      setError("You can't book an appointment in the past — please pick a future date and time.");
      return;
    }

    setSaving(true);
    try {
      await onSave({
        patientId: Number(patientId),
        reason,
        appointmentDate: appointmentDate.toISOString(),
        notes,
        staffId: staffId ? Number(staffId) : undefined,
      });
    } catch (e) {
      setError(e.message || "Failed to book appointment.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Book Appointment</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Schedule a new visit</p>
      <ErrorBanner message={error} />

      <div className="form-grid">
        <Field label="Select Animal">
          <select style={inputStyle} value={patientId} onChange={(e) => setPatientId(e.target.value)}>
            {patients.length === 0 && <option value="">No animal records yet — add one first</option>}
            {patients.map((p) => (
              <option key={p.id} value={p.id}>{p.name} ({p.species}{p.ownerName ? ` — ${p.ownerName}` : ""})</option>
            ))}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" style={inputStyle} value={date} min={todayStr()} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label="Time">
          <input type="time" style={inputStyle} value={time} onChange={(e) => setTime(e.target.value)} />
        </Field>
        <Field label="Preferred Vet (optional)">
          <select style={inputStyle} value={staffId} onChange={(e) => setStaffId(e.target.value)}>
            <option value="">No preference — any available vet</option>
            {vets.map((v) => (
              <option key={v.id} value={v.id}>Dr. {v.firstName} {v.lastName}</option>
            ))}
          </select>
        </Field>
      </div>

      <Field label="Reason for Visit">
        <textarea
          style={{ ...inputStyle, height: 100, resize: "vertical" }}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. Annual vaccination, follow-up checkup..."
        />
      </Field>

      <Field label="Notes (optional)">
        <input style={inputStyle} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything the vet should know beforehand" />
      </Field>

      <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 8, padding: "14px 18px", marginTop: 8, marginBottom: 20 }}>
        <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Typical price guide</div>
        {Object.entries(groupByCategory(services)).map(([category, items]) => (
          <div key={category} style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#0d9488", marginTop: 6 }}>{category}</div>
            {items.map((s) => (
              <div key={s.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "#475569", padding: "3px 0" }}>
                <span>{s.service}</span>
                <span>{money(s.price)}</span>
              </div>
            ))}
          </div>
        ))}
        <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 8 }}>
          These are the clinic's standard prices — your actual invoice depends on what the vet finds during your visit.
        </div>
      </div>

      <div>
        <button style={primaryBtn} onClick={submit} disabled={saving || !patientId}>{saving ? "Booking..." : "Confirm Booking"}</button>
        <button style={secondaryBtn} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
