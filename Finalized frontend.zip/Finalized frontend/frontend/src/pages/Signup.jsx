import React, { useState } from "react";
import { Field } from "../components/ui";
import { inputStyle, primaryBtn } from "../utils/styles";
import { useAuth } from "../context/AuthContext";

const ROLES = [
  { value: "client", label: "Pet Owner / Client" },
  { value: "vet", label: "Veterinarian" },
  { value: "receptionist", label: "Receptionist" },
  { value: "admin", label: "Admin" },
];

export default function Signup({ goToLogin }) {
  const { signup, error, loading } = useAuth();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("client");

  function submit(e) {
    e.preventDefault();
    signup({ firstName, lastName, email, password, role });
  }

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f8fafc" }}>
      <form onSubmit={submit} style={{ width: 380, maxWidth: "90vw", background: "#fff", border: "1px solid #e2e8f0", borderRadius: 8, padding: 32 }}>
        <div style={{ fontWeight: 700, fontSize: 20, color: "#1e293b", marginBottom: 4 }}>VetCare Manager</div>
        <p style={{ color: "#64748b", marginBottom: 24, fontSize: 14 }}>Create your account</p>

        <Field label="I am a...">
          <select style={inputStyle} value={role} onChange={(e) => setRole(e.target.value)}>
            {ROLES.map((r) => (
              <option key={r.value} value={r.value}>{r.label}</option>
            ))}
          </select>
        </Field>
        <Field label="First Name">
          <input style={inputStyle} value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Jane" required />
        </Field>
        <Field label="Last Name">
          <input style={inputStyle} value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Doe" required />
        </Field>
        <Field label="Email Address">
          <input type="email" style={inputStyle} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
        </Field>
        <Field label="Password">
          <input type="password" style={inputStyle} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" required minLength={8} />
        </Field>

        {error && <p style={{ color: "#dc2626", fontSize: 13, marginBottom: 12 }}>{error}</p>}

        <button type="submit" style={{ ...primaryBtn, width: "100%" }} disabled={loading}>
          {loading ? "Creating account..." : "Create Account"}
        </button>

        <p style={{ marginTop: 16, fontSize: 13, color: "#64748b", textAlign: "center" }}>
          Already have an account?{" "}
          <span style={{ color: "#0d9488", cursor: "pointer", fontWeight: 600 }} onClick={goToLogin}>
            Sign in
          </span>
        </p>
      </form>
    </div>
  );
}
