import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, inputStyle, primaryBtn } from "../utils/styles";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import OwnerForm from "./OwnerForm";

const STAFF_ROLES = ["vet", "receptionist", "admin"];

export default function Owners({ focusRecord, clearFocus }) {
  const { user } = useAuth();
  const isStaff = STAFF_ROLES.includes(user?.role);

  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");

  const [editing, setEditing] = useState(focusRecord && focusRecord.type === "owner" ? focusRecord.data : null);
  const [showForm, setShowForm] = useState(!!editing);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/api/owners");
      setOwners(res.owners || []);
    } catch (e) {
      setError(e.message || "Failed to load owners.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const visible = owners.filter((o) => o.fullName.toLowerCase().includes(query.toLowerCase()));

  async function save(form, id) {
    setError("");
    if (id) {
      await api.patch(`/api/owners/${id}`, form);
    } else {
      await api.post("/api/owners", form);
    }
    setShowForm(false);
    clearFocus();
    await load();
  }

  async function openEdit(o) {
    // Pull full detail (with linked animals) before opening the form.
    try {
      const res = await api.get(`/api/owners/${o.id}`);
      setEditing(res.owner);
    } catch {
      setEditing(o);
    }
    setShowForm(true);
  }

  if (showForm) {
    return (
      <OwnerForm
        initial={editing}
        isStaff={isStaff}
        onCancel={() => { setShowForm(false); clearFocus(); }}
        onSave={save}
      />
    );
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 16 }}>Owner Records</h1>
      <ErrorBanner message={error} />
      <div className="page-toolbar">
        <input placeholder="Search owners..." value={query} onChange={(e) => setQuery(e.target.value)} style={inputStyle} />
        {isStaff && <button style={primaryBtn} onClick={() => { setEditing(null); setShowForm(true); }}>+ Add Owner</button>}
      </div>

      {loading ? <Loading label="Loading owners..." /> : (
        <>
          <div className="table-scroll">
            <table style={tableStyle}>
              <thead>
                <tr>
                  <Th>Name</Th>
                  <Th>Phone</Th>
                  <Th>Email</Th>
                  <Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {visible.map((o, i) => (
                  <tr key={o.id} style={rowStyle(i)}>
                    <Td>{o.fullName}</Td>
                    <Td>{o.phone || "—"}</Td>
                    <Td>{o.email || "—"}</Td>
                    <Td><Link onClick={() => openEdit(o)}>View / Edit</Link></Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p style={{ color: "#64748b", fontSize: 13, marginTop: 12 }}>Showing {visible.length} of {owners.length} owners</p>
        </>
      )}
    </div>
  );
}
