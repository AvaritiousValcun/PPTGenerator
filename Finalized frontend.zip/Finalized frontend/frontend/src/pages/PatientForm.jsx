import React, { useState, useEffect } from "react";
import { Field, ErrorBanner } from "../components/ui";
import { inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";
import { formatDate } from "../utils/helpers";
import { api } from "../api/client";

export default function PatientForm({ initial, owners, isStaff, currentUser, onCancel, onSave }) {
  const readOnly = !isStaff && !!initial;

  const myOwners = isStaff ? owners : owners.filter((o) => o.userId === currentUser?.id);

  const [ownerId, setOwnerId] = useState(initial?.ownerId || myOwners[0]?.id || "");
  const [name, setName] = useState(initial?.name || "");
  const [species, setSpecies] = useState(initial?.species || "");
  const [breed, setBreed] = useState(initial?.breed || "");
  const [sex, setSex] = useState(initial?.sex || "unknown");
  const [dateOfBirth, setDateOfBirth] = useState(initial?.dateOfBirth || "");
  const [weightKg, setWeightKg] = useState(initial?.weightKg || "");
  const [color, setColor] = useState(initial?.color || "");
  const [microchipId, setMicrochipId] = useState(initial?.microchipId || "");
  const [allergies, setAllergies] = useState(initial?.allergies || "");
  const [medicalNotes, setMedicalNotes] = useState(initial?.medicalNotes || "");
  const [status, setStatus] = useState(initial?.status || "active");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(!!initial);

  useEffect(() => {
    if (!initial) return;
    let cancelled = false;
    api.get(`/api/medical-reports/patient/${initial.id}`)
      .then((res) => { if (!cancelled) setHistory(res.reports || []); })
      .catch(() => {})
      .finally(() => { if (!cancelled) setHistoryLoading(false); });
    return () => { cancelled = true; };
  }, [initial]);

  async function submit() {
    setSaving(true);
    setError("");
    try {
      await onSave(
        {
          ownerId: Number(ownerId),
          name,
          species,
          breed,
          sex,
          dateOfBirth: dateOfBirth || undefined,
          weightKg: weightKg ? Number(weightKg) : undefined,
          color,
          microchipId,
          allergies,
          medicalNotes,
          status,
        },
        initial?.id
      );
    } catch (e) {
      setError(e.message || "Failed to save animal record.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>{readOnly ? "Animal Record" : initial ? "Edit Animal Record" : "Add Animal Record"}</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>
        {readOnly ? "Viewing this record — contact the clinic to request changes." : "Enter the animal's details below"}
      </p>
      <ErrorBanner message={error} />

      <div className="form-grid">
        <Field label="Owner">
          <select style={inputStyle} value={ownerId} onChange={(e) => setOwnerId(e.target.value)} disabled={readOnly || !isStaff}>
            {myOwners.length === 0 && <option value="">No owner record found</option>}
            {myOwners.map((o) => (
              <option key={o.id} value={o.id}>{o.fullName}</option>
            ))}
          </select>
        </Field>
        <Field label="Animal Name">
          <input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Bella" disabled={readOnly} required />
        </Field>
        <Field label="Species">
          <input style={inputStyle} value={species} onChange={(e) => setSpecies(e.target.value)} placeholder="e.g. Dog" disabled={readOnly} required />
        </Field>
        <Field label="Breed">
          <input style={inputStyle} value={breed} onChange={(e) => setBreed(e.target.value)} placeholder="e.g. Labrador" disabled={readOnly} />
        </Field>
        <Field label="Sex">
          <select style={inputStyle} value={sex} onChange={(e) => setSex(e.target.value)} disabled={readOnly}>
            <option value="unknown">Unknown</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </Field>
        <Field label="Date of Birth">
          <input type="date" style={inputStyle} value={dateOfBirth || ""} onChange={(e) => setDateOfBirth(e.target.value)} disabled={readOnly} />
        </Field>
        <Field label="Weight (kg)">
          <input type="number" step="0.1" style={inputStyle} value={weightKg || ""} onChange={(e) => setWeightKg(e.target.value)} disabled={readOnly} />
        </Field>
        <Field label="Color">
          <input style={inputStyle} value={color} onChange={(e) => setColor(e.target.value)} placeholder="e.g. Golden" disabled={readOnly} />
        </Field>
        <Field label="Microchip ID">
          <input style={inputStyle} value={microchipId} onChange={(e) => setMicrochipId(e.target.value)} disabled={readOnly} />
        </Field>
        {isStaff && (
          <Field label="Status">
            <select style={inputStyle} value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="deceased">Deceased</option>
            </select>
          </Field>
        )}
      </div>

      <Field label="Allergies">
        <input style={inputStyle} value={allergies} onChange={(e) => setAllergies(e.target.value)} placeholder="e.g. Penicillin" disabled={readOnly} />
      </Field>

      {(isStaff || medicalNotes) && (
        <Field label="Medical Notes">
          <textarea
            style={{ ...inputStyle, height: 100, resize: "vertical" }}
            value={medicalNotes}
            onChange={(e) => setMedicalNotes(e.target.value)}
            placeholder="Vaccination history, ongoing conditions, treatment notes..."
            disabled={!isStaff}
          />
        </Field>
      )}

      {initial && (
        <div style={{ marginTop: 8 }}>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}>Medical History</div>
          {historyLoading ? (
            <p style={{ color: "#94a3b8", fontSize: 14 }}>Loading history...</p>
          ) : history.length === 0 ? (
            <p style={{ color: "#94a3b8", fontSize: 14 }}>No past visits recorded yet.</p>
          ) : (
            history.map((r) => (
              <div key={r.id} style={{ border: "1px solid #e2e8f0", borderRadius: 8, padding: "12px 16px", marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "#64748b", marginBottom: 6 }}>
                  <span>{formatDate(r.createdAt)}{r.veterinarianName ? ` · Dr. ${r.veterinarianName}` : ""}</span>
                </div>
                <div style={{ fontSize: 14 }}><strong>Diagnosis:</strong> {r.diagnosis}</div>
                {r.treatmentPlan && <div style={{ fontSize: 14, marginTop: 4 }}><strong>Treatment:</strong> {r.treatmentPlan}</div>}
                {r.prescriptions && <div style={{ fontSize: 14, marginTop: 4 }}><strong>Prescriptions:</strong> {r.prescriptions}</div>}
              </div>
            ))
          )}
        </div>
      )}

      <div style={{ marginTop: 16 }}>
        {!readOnly && (
          <button style={primaryBtn} onClick={submit} disabled={saving || !ownerId}>
            {saving ? "Saving..." : "Save Animal Record"}
          </button>
        )}
        <button style={readOnly ? primaryBtn : secondaryBtn} onClick={onCancel}>{readOnly ? "Close" : "Cancel"}</button>
      </div>
    </div>
  );
}
