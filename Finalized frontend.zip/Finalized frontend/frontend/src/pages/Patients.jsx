import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, inputStyle, primaryBtn } from "../utils/styles";
import { calcAge } from "../utils/helpers";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import PatientForm from "./PatientForm";

const STAFF_ROLES = ["vet", "receptionist", "admin"];

export default function Patients({ focusRecord, clearFocus }) {
  const { user } = useAuth();
  const isStaff = STAFF_ROLES.includes(user?.role);

  const [patients, setPatients] = useState([]);
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");

  const [editing, setEditing] = useState(focusRecord && focusRecord.type === "patient" ? focusRecord.data : null);
  const [showForm, setShowForm] = useState(!!editing);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [pRes, oRes] = await Promise.all([api.get("/api/patients"), api.get("/api/owners")]);
      setPatients(pRes.patients || []);
      setOwners(oRes.owners || []);
    } catch (e) {
      setError(e.message || "Failed to load animal records.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const visible = patients.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    (p.species || "").toLowerCase().includes(query.toLowerCase()) ||
    (p.ownerName || "").toLowerCase().includes(query.toLowerCase())
  );

  async function save(form, id) {
    setError("");
    if (id) {
      await api.patch(`/api/patients/${id}`, form);
    } else {
      await api.post("/api/patients", form);
    }
    setShowForm(false);
    clearFocus();
    await load();
  }

  async function remove(id) {
    if (!window.confirm("Delete this animal record? This cannot be undone.")) return;
    setError("");
    try {
      await api.del(`/api/patients/${id}`);
      await load();
    } catch (e) {
      setError(e.message || "Failed to delete animal record.");
    }
  }

  if (showForm) {
    return (
      <PatientForm
        initial={editing}
        owners={owners}
        isStaff={isStaff}
        currentUser={user}
        onCancel={() => { setShowForm(false); clearFocus(); }}
        onSave={save}
      />
    );
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 16 }}>Animal Records</h1>
      <ErrorBanner message={error} />
      <div className="page-toolbar">
        <input placeholder="Search by name, species, or owner..." value={query} onChange={(e) => setQuery(e.target.value)} style={inputStyle} />
        <button style={primaryBtn} onClick={() => { setEditing(null); setShowForm(true); }}>+ Add Animal</button>
      </div>

      {loading ? <Loading label="Loading animal records..." /> : (
        <>
          <div className="table-scroll">
            <table style={tableStyle}>
              <thead>
                <tr>
                  <Th>Name</Th>
                  <Th>Species</Th>
                  <Th>Breed</Th>
                  <Th>Owner</Th>
                  <Th>Age</Th>
                  <Th>Status</Th>
                  <Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {visible.map((p, i) => (
                  <tr key={p.id} style={rowStyle(i)}>
                    <Td>{p.name}</Td>
                    <Td>{p.species}</Td>
                    <Td>{p.breed || "—"}</Td>
                    <Td>{p.ownerName || "—"}</Td>
                    <Td>{calcAge(p.dateOfBirth)}</Td>
                    <Td style={{ textTransform: "capitalize" }}>{p.status}</Td>
                    <Td>
                      <Link onClick={() => { setEditing(p); setShowForm(true); }}>{isStaff ? "View / Edit" : "View"}</Link>
                      {isStaff && (
                        <>
                          {" / "}
                          <Link onClick={() => remove(p.id)}>Delete</Link>
                        </>
                      )}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p style={{ color: "#64748b", fontSize: 13, marginTop: 12 }}>Showing {visible.length} of {patients.length} animal records</p>
        </>
      )}
    </div>
  );
}
