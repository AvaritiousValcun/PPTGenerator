import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle } from "../utils/styles";
import { formatDate, formatTime } from "../utils/helpers";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Dashboard({ goTo }) {
  const { user } = useAuth();
  const isVet = user?.role === "vet";
  const isFrontDesk = user?.role === "receptionist" || user?.role === "admin";
  const isStaff = isVet || isFrontDesk;

  const [patients, setPatients] = useState([]);
  const [owners, setOwners] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const calls = [api.get("/api/patients"), api.get("/api/appointments")];
      if (isFrontDesk) calls.push(api.get("/api/owners"));
      const [pRes, aRes, oRes] = await Promise.all(calls);
      setPatients(pRes.patients || []);
      setAppointments(aRes.appointments || []);
      if (oRes) setOwners(oRes.owners || []);
    } catch (e) {
      setError(e.message || "Failed to load dashboard data.");
    } finally {
      setLoading(false);
    }
  }, [isFrontDesk]);

  useEffect(() => { load(); }, [load]);

  async function setStatus(id, status) {
    setError("");
    try {
      await api.patch(`/api/appointments/${id}`, { status });
      await load();
    } catch (e) {
      setError(e.message || "Failed to update appointment.");
    }
  }

  async function claim(id) {
    setError("");
    try {
      await api.patch(`/api/appointments/${id}`, { staffId: user.id });
      await load();
    } catch (e) {
      setError(e.message || "Failed to assign appointment.");
    }
  }

  const activeAppts = appointments.filter((a) => a.status !== "cancelled" && a.status !== "completed");

  if (isVet) {
    const myAppointments = activeAppts
      .filter((a) => Number(a.staffId) === Number(user.id))
      .sort((a, b) => new Date(a.appointmentDate) - new Date(b.appointmentDate));
    const unassigned = activeAppts
      .filter((a) => !a.staffId)
      .sort((a, b) => new Date(a.appointmentDate) - new Date(b.appointmentDate));
    const todayStr = new Date().toDateString();
    const myToday = myAppointments.filter((a) => new Date(a.appointmentDate).toDateString() === todayStr);

    return (
      <div>
        <h1 style={{ fontSize: 26, marginBottom: 4 }}>Dashboard</h1>
        <p style={{ color: "#64748b", marginBottom: 24 }}>Welcome back, Dr. {user?.lastName}. Here's your clinical overview.</p>
        <ErrorBanner message={error} />

        {loading ? <Loading label="Loading dashboard..." /> : (
          <>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 16, marginBottom: 32 }}>
              <StatCard label="Animal records" value={patients.length} onClick={() => goTo("Patients")} />
              <StatCard label="My appointments today" value={myToday.length} />
              <StatCard label="Unassigned appointments" value={unassigned.length} />
            </div>

            <h2 style={{ fontSize: 18, marginBottom: 12 }}>My upcoming appointments</h2>
            {myAppointments.length === 0 ? (
              <p style={{ color: "#64748b", marginBottom: 28 }}>Nothing assigned to you yet — check unassigned appointments below.</p>
            ) : (
              <div className="table-scroll" style={{ marginBottom: 28 }}>
                <table style={tableStyle}>
                  <thead>
                    <tr>
                      <Th>Date</Th><Th>Time</Th><Th>Patient</Th><Th>Reason</Th><Th>Status</Th><Th>Actions</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {myAppointments.map((a, i) => (
                      <tr key={a.id} style={rowStyle(i)}>
                        <Td>{formatDate(a.appointmentDate)}</Td>
                        <Td>{formatTime(a.appointmentDate)}</Td>
                        <Td>{a.petName} <span style={{ color: "#94a3b8" }}>({a.petType})</span></Td>
                        <Td>{a.reason}</Td>
                        <Td style={{ textTransform: "capitalize" }}>{a.status}</Td>
                        <Td>
                          {a.status !== "confirmed" && <Link onClick={() => setStatus(a.id, "confirmed")}>Confirm</Link>}
                          {a.status !== "confirmed" && " / "}
                          <Link onClick={() => setStatus(a.id, "completed")}>Complete</Link>
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <h2 style={{ fontSize: 18, marginBottom: 12 }}>Unassigned appointments</h2>
            {unassigned.length === 0 ? (
              <p style={{ color: "#64748b" }}>Nothing unassigned right now.</p>
            ) : (
              <div className="table-scroll">
                <table style={tableStyle}>
                  <thead>
                    <tr>
                      <Th>Date</Th><Th>Time</Th><Th>Patient</Th><Th>Reason</Th><Th>Actions</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {unassigned.map((a, i) => (
                      <tr key={a.id} style={rowStyle(i)}>
                        <Td>{formatDate(a.appointmentDate)}</Td>
                        <Td>{formatTime(a.appointmentDate)}</Td>
                        <Td>{a.petName} <span style={{ color: "#94a3b8" }}>({a.petType})</span></Td>
                        <Td>{a.reason}</Td>
                        <Td><Link onClick={() => claim(a.id)}>Assign to me</Link></Td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  // Front desk (receptionist / admin) and client dashboards share the
  // simpler practice/personal overview layout.
  const upcoming = activeAppts
    .sort((a, b) => new Date(a.appointmentDate) - new Date(b.appointmentDate))
    .slice(0, 5);

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Dashboard</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>
        Welcome back, {user?.firstName}. Here's an overview of {isFrontDesk ? "the practice" : "your pets and visits"}.
      </p>
      <ErrorBanner message={error} />

      {loading ? <Loading label="Loading dashboard..." /> : (
        <>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 16, marginBottom: 32 }}>
            <StatCard label="Animals" value={patients.length} onClick={() => goTo("Patients")} />
            {isFrontDesk && <StatCard label="Owners" value={owners.length} onClick={() => goTo("Owners")} />}
            <StatCard label="Upcoming appointments" value={upcoming.length} onClick={() => goTo("Appointments")} />
          </div>

          <h2 style={{ fontSize: 18, marginBottom: 12 }}>Next up</h2>
          {upcoming.length === 0 ? (
            <p style={{ color: "#64748b" }}>No upcoming appointments.</p>
          ) : (
            <div className="table-scroll">
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <Th>Date</Th><Th>Time</Th><Th>Patient</Th><Th>Reason</Th>
                    {isFrontDesk && <Th>Vet</Th>}
                  </tr>
                </thead>
                <tbody>
                  {upcoming.map((a, i) => (
                    <tr key={a.id} style={rowStyle(i)}>
                      <Td>{formatDate(a.appointmentDate)}</Td>
                      <Td>{formatTime(a.appointmentDate)}</Td>
                      <Td>{a.petName}</Td>
                      <Td>{a.reason}</Td>
                      {isFrontDesk && <Td>{a.assignedStaffName || "Unassigned"}</Td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, onClick }) {
  return (
    <div onClick={onClick} style={{ cursor: onClick ? "pointer" : "default", flex: "1 1 160px", minWidth: 160, border: "1px solid #e2e8f0", borderRadius: 8, padding: "18px 20px" }}>
      <div style={{ fontSize: 28, fontWeight: 700, color: "#0d9488" }}>{value}</div>
      <div style={{ color: "#64748b", fontSize: 14 }}>{label}</div>
    </div>
  );
}
