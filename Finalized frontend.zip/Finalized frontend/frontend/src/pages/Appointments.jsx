import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, primaryBtn, secondaryBtn } from "../utils/styles";
import { formatDate, formatTime } from "../utils/helpers";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import AppointmentForm from "./AppointmentForm";
import MedicalReport from "./MedicalReport";

const STAFF_ROLES = ["vet", "receptionist", "admin"];

export default function Appointments({ focusRecord, clearFocus }) {
  const { user } = useAuth();
  const isStaff = STAFF_ROLES.includes(user?.role);
  const canWriteReports = user?.role === "vet" || user?.role === "admin";

  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [editing, setEditing] = useState(focusRecord && focusRecord.type === "appointment" ? focusRecord.data : null);
  const [showForm, setShowForm] = useState(!!editing);
  const [reportFor, setReportFor] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [aRes, pRes] = await Promise.all([api.get("/api/appointments"), api.get("/api/patients")]);
      setAppointments(aRes.appointments || []);
      setPatients(pRes.patients || []);
    } catch (e) {
      setError(e.message || "Failed to load appointments.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(form) {
    setError("");
    await api.post("/api/appointments", form);
    setShowForm(false);
    clearFocus();
    await load();
  }

  async function setStatus(id, status) {
    setError("");
    try {
      await api.patch(`/api/appointments/${id}`, { status });
      await load();
    } catch (e) {
      setError(e.message || "Failed to update appointment.");
    }
  }

  if (showForm) {
    return (
      <AppointmentForm
        patients={patients}
        onCancel={() => { setShowForm(false); clearFocus(); }}
        onSave={save}
      />
    );
  }

  if (reportFor) {
    return (
      <MedicalReport
        appointment={reportFor}
        canWrite={canWriteReports}
        onBack={() => setReportFor(null)}
        onSaved={load}
      />
    );
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 16 }}>Appointments</h1>
      <ErrorBanner message={error} />
      <div className="page-toolbar">
        <div />
        <button style={primaryBtn} onClick={() => { setEditing(null); setShowForm(true); }}>+ New Appointment</button>
      </div>

      {loading ? <Loading label="Loading appointments..." /> : (
        <>
          <div className="table-scroll">
            <table style={tableStyle}>
              <thead>
                <tr>
                  <Th>Date</Th>
                  <Th>Time</Th>
                  <Th>Patient</Th>
                  {isStaff && <Th>Client</Th>}
                  <Th>Reason</Th>
                  <Th>Vet</Th>
                  <Th>Status</Th>
                  <Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((a, i) => (
                  <tr key={a.id} style={rowStyle(i)}>
                    <Td>{formatDate(a.appointmentDate)}</Td>
                    <Td>{formatTime(a.appointmentDate)}</Td>
                    <Td>{a.petName} <span style={{ color: "#94a3b8" }}>({a.petType})</span></Td>
                    {isStaff && <Td>{a.clientName}</Td>}
                    <Td>{a.reason}</Td>
                    <Td>{a.assignedStaffName || "Unassigned"}</Td>
                    <Td style={{ textTransform: "capitalize" }}>{a.status}</Td>
                    <Td>
                      {isStaff && a.status !== "confirmed" && a.status !== "completed" && a.status !== "cancelled" && (
                        <><Link onClick={() => setStatus(a.id, "confirmed")}>Confirm</Link>{" / "}</>
                      )}
                      {isStaff && a.status !== "cancelled" && a.status !== "completed" && (
                        <><Link onClick={() => setStatus(a.id, "cancelled")}>Cancel</Link>{" / "}</>
                      )}
                      {a.status === "completed" ? (
                        <Link onClick={() => setReportFor(a)}>View Report</Link>
                      ) : (
                        canWriteReports && a.status !== "cancelled" && <Link onClick={() => setReportFor(a)}>Write Report</Link>
                      )}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p style={{ color: "#64748b", fontSize: 13, marginTop: 12 }}>Showing {appointments.length} appointments</p>
        </>
      )}
    </div>
  );
}
