import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, inputStyle, primaryBtn } from "../utils/styles";
import { money, formatDate } from "../utils/helpers";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Search({ goTo }) {
  const { user } = useAuth();
  const isStaff = ["vet", "receptionist", "admin"].includes(user?.role);
  const [query, setQuery] = useState("");
  const [patients, setPatients] = useState([]);
  const [owners, setOwners] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [pRes, oRes, aRes, iRes] = await Promise.all([
        api.get("/api/patients"),
        api.get("/api/owners"),
        api.get("/api/appointments"),
        api.get("/api/billing/invoices"),
      ]);
      setPatients(pRes.patients || []);
      setOwners(oRes.owners || []);
      setAppointments(aRes.appointments || []);
      setInvoices(iRes.invoices || []);
    } catch (e) {
      setError(e.message || "Failed to load search data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const q = query.trim().toLowerCase();
  const results = [];

  if (q) {
    patients
      .filter((p) => p.name.toLowerCase().includes(q))
      .forEach((p) =>
        results.push({
          type: "Animal",
          name: `${p.name} (${p.species})`,
          related: p.ownerName || "—",
          info: p.breed || "",
          actionLabel: "View Record",
          onClick: () => goTo("Patients", { type: "patient", data: p }),
        })
      );

    appointments
      .filter((a) => a.petName.toLowerCase().includes(q))
      .forEach((a) =>
        results.push({
          type: "Appointment",
          name: `${a.petName} - ${a.reason}`,
          related: formatDate(a.appointmentDate),
          info: a.assignedStaffName || "Unassigned",
          actionLabel: "View",
          onClick: () => goTo("Appointments", { type: "appointment", data: a }),
        })
      );

    invoices
      .filter((inv) => (inv.patientName || "").toLowerCase().includes(q) || String(inv.id).includes(q))
      .forEach((inv) =>
        results.push({
          type: "Invoice",
          name: `INV-${inv.id}`,
          related: `${inv.patientName} / ${inv.ownerName || ""}`,
          info: money(inv.amount),
          actionLabel: "View Invoice",
          onClick: () => goTo("Billing", { type: "invoice", data: inv }),
        })
      );

    if (isStaff) {
      owners
        .filter((o) => o.fullName.toLowerCase().includes(q))
        .forEach((o) =>
          results.push({
            type: "Owner",
            name: o.fullName,
            related: o.phone || "",
            info: o.email || "",
            actionLabel: "View / Edit",
            onClick: () => goTo("Owners", { type: "owner", data: o }),
          })
        );
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 16 }}>Search Results</h1>
      <ErrorBanner message={error} />
      <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
        <input style={{ ...inputStyle, flex: "1 1 200px" }} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search animals, owners, appointments, invoices..." />
        <button style={primaryBtn}>Search</button>
      </div>

      {loading ? <Loading label="Loading..." /> : (
        <>
          <p style={{ color: "#64748b", marginBottom: 12 }}>{q ? `${results.length} results found for "${query}"` : "Start typing to search."}</p>

          {q && (
            <div className="table-scroll">
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <Th>Type</Th>
                    <Th>Name</Th>
                    <Th>Related To</Th>
                    <Th>Info</Th>
                    <Th>Actions</Th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((r, i) => (
                    <tr key={i} style={rowStyle(i)}>
                      <Td>{r.type}</Td>
                      <Td>{r.name}</Td>
                      <Td>{r.related}</Td>
                      <Td>{r.info}</Td>
                      <Td><Link onClick={r.onClick}>{r.actionLabel}</Link></Td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <p style={{ color: "#94a3b8", fontSize: 13, marginTop: 16 }}>Tip: search by animal name, owner name, or invoice number</p>
        </>
      )}
    </div>
  );
}
