import React, { useState } from "react";
import { Field } from "../components/ui";
import { inputStyle, primaryBtn } from "../utils/styles";
import { useAuth } from "../context/AuthContext";

export default function Login({ goToSignup }) {
  const { login, error, loading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function submit(e) {
    e.preventDefault();
    login(email, password);
  }

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f8fafc" }}>
      <form onSubmit={submit} style={{ width: 380, maxWidth: "90vw", background: "#fff", border: "1px solid #e2e8f0", borderRadius: 8, padding: 32 }}>
        <div style={{ fontWeight: 700, fontSize: 20, color: "#1e293b", marginBottom: 4 }}>VetCare Manager</div>
        <p style={{ color: "#64748b", marginBottom: 24, fontSize: 14 }}>Sign in to your account</p>

        <Field label="Email Address">
          <input type="email" style={inputStyle} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
        </Field>
        <Field label="Password">
          <input type="password" style={inputStyle} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
        </Field>

        {error && <p style={{ color: "#dc2626", fontSize: 13, marginBottom: 12 }}>{error}</p>}

        <button type="submit" style={{ ...primaryBtn, width: "100%" }} disabled={loading}>
          {loading ? "Signing in..." : "Sign In"}
        </button>

        <p style={{ marginTop: 16, fontSize: 13, color: "#64748b", textAlign: "center" }}>
          Don't have an account?{" "}
          <span style={{ color: "#0d9488", cursor: "pointer", fontWeight: 600 }} onClick={goToSignup}>
            Sign up
          </span>
        </p>
      </form>
    </div>
  );
}
