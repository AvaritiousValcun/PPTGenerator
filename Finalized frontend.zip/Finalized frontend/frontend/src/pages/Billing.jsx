import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";
import { money, formatDate } from "../utils/helpers";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";

const STAFF_ROLES = ["vet", "receptionist", "admin"];

export default function Billing({ focusRecord }) {
  const { user } = useAuth();
  const isStaff = STAFF_ROLES.includes(user?.role);

  const [invoices, setInvoices] = useState([]);
  const [patients, setPatients] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [view, setView] = useState("list"); // list | detail | create
  const [active, setActive] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const calls = [api.get("/api/billing/invoices"), api.get("/api/billing/services")];
      if (isStaff) calls.push(api.get("/api/patients"));
      const [iRes, sRes, pRes] = await Promise.all(calls);
      setInvoices(iRes.invoices || []);
      setServices(sRes.services || []);
      if (pRes) setPatients(pRes.patients || []);
    } catch (e) {
      setError(e.message || "Failed to load invoices.");
    } finally {
      setLoading(false);
    }
  }, [isStaff]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (focusRecord && focusRecord.type === "invoice") openDetail(focusRecord.data.id);
  }, [focusRecord]);

  async function openDetail(id) {
    setError("");
    try {
      const res = await api.get(`/api/billing/invoices/${id}`);
      setActive(res.invoice);
      setView("detail");
    } catch (e) {
      setError(e.message || "Failed to load invoice.");
    }
  }

  if (view === "create") {
    return (
      <InvoiceForm
        patients={patients}
        services={services}
        onCancel={() => setView("list")}
        onSaved={async () => { setView("list"); await load(); }}
      />
    );
  }

  if (view === "detail" && active) {
    return (
      <InvoiceDetail
        invoice={active}
        isStaff={isStaff}
        onBack={() => setView("list")}
        onChanged={async () => { await openDetail(active.id); await load(); }}
      />
    );
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 16 }}>Billing / Invoices</h1>
      <ErrorBanner message={error} />
      {isStaff && (
        <div className="page-toolbar">
          <div />
          <button style={primaryBtn} onClick={() => setView("create")}>+ New Invoice</button>
        </div>
      )}

      {loading ? <Loading label="Loading invoices..." /> : invoices.length === 0 ? (
        <p style={{ color: "#64748b" }}>No invoices yet.</p>
      ) : (
        <div className="table-scroll">
          <table style={tableStyle}>
            <thead>
              <tr>
                <Th>Invoice</Th>
                <Th>Patient</Th>
                {isStaff && <Th>Owner</Th>}
                <Th>Date</Th>
                <Th>Amount</Th>
                <Th>Status</Th>
                <Th>Actions</Th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv, i) => (
                <tr key={inv.id} style={rowStyle(i)}>
                  <Td>INV-{inv.id}</Td>
                  <Td>{inv.patientName}</Td>
                  {isStaff && <Td>{inv.ownerName}</Td>}
                  <Td>{formatDate(inv.createdAt)}</Td>
                  <Td>{money(inv.amount)}</Td>
                  <Td style={{ textTransform: "capitalize" }}>{(inv.status || "").toLowerCase()}</Td>
                  <Td><Link onClick={() => openDetail(inv.id)}>View Invoice</Link></Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function InvoiceDetail({ invoice, isStaff, onBack, onChanged }) {
  const [phone, setPhone] = useState(invoice.ownerPhone || "");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [marking, setMarking] = useState(false);

  const isPaid = (invoice.status || "").toUpperCase() === "PAID";

  async function sendPrompt() {
    setError("");
    if (!phone) {
      setError("Enter the phone number to send the payment prompt to.");
      return;
    }
    setSending(true);
    try {
      const res = await api.post("/api/billing/stkpush", { phone, amount: invoice.amount, invoiceId: invoice.id });
      if (res.mocked) {
        alert("Demo mode: M-Pesa sandbox isn't connected, so this payment was simulated and the invoice has been marked paid.");
      } else {
        alert("Payment prompt sent. The invoice will update automatically once the client confirms on their phone.");
      }
      await onChanged();
    } catch (e) {
      setError(e.message || "Failed to send payment prompt.");
    } finally {
      setSending(false);
    }
  }

  async function markPaid(method) {
    setError("");
    setMarking(true);
    try {
      await api.patch(`/api/billing/invoices/${invoice.id}/pay`, { method });
      await onChanged();
    } catch (e) {
      setError(e.message || "Failed to record payment.");
    } finally {
      setMarking(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Billing / Invoice</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Invoice #{invoice.id}</p>
      <ErrorBanner message={error} />

      <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 8, padding: 20, display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <div style={{ fontWeight: 600 }}>Patient: {invoice.patientName}</div>
          <div style={{ color: "#64748b", fontSize: 14 }}>Owner: {invoice.ownerName}</div>
        </div>
        <div>
          <div style={{ fontWeight: 600 }}>Date: {formatDate(invoice.createdAt)}</div>
          <div style={{ color: "#64748b", fontSize: 14 }}>
            Status: <span style={{ textTransform: "capitalize" }}>{(invoice.status || "").toLowerCase()}</span>
            {isPaid && invoice.paymentMethod && <span> — paid via {invoice.paymentMethod === "mpesa" ? "M-Pesa" : invoice.paymentMethod.replace("_", " ")}</span>}
          </div>
        </div>
      </div>

      <div className="table-scroll">
        <table style={tableStyle}>
          <thead>
            <tr>
              <Th>Service</Th>
              <Th>Description</Th>
              <Th>Cost (KES)</Th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item, i) => (
              <tr key={item.id || i} style={rowStyle(i)}>
                <Td>{item.service}</Td>
                <Td>{item.description || "—"}</Td>
                <Td>{money(item.cost)}</Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ textAlign: "right", marginTop: 12, marginBottom: 20 }}>
        <span style={{ fontWeight: 700 }}>Total: </span>
        <span style={{ fontWeight: 700, color: "#0d9488" }}>{money(invoice.amount)}</span>
      </div>

      {isStaff && !isPaid && (
        <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 8, padding: 20, marginBottom: 20 }}>
          <div style={{ fontWeight: 600, marginBottom: 12 }}>Take Payment</div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end", marginBottom: 12 }}>
            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 13, color: "#64748b", marginBottom: 4 }}>Client's M-Pesa phone number</div>
              <input style={inputStyle} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. 254712345678" />
            </div>
            <button style={primaryBtn} onClick={sendPrompt} disabled={sending}>{sending ? "Sending..." : "Send M-Pesa Prompt"}</button>
          </div>

          <div style={{ fontSize: 13, color: "#64748b", marginBottom: 8 }}>Or, if the client paid another way:</div>
          <button style={secondaryBtn} onClick={() => markPaid("cash")} disabled={marking}>Mark Paid — Cash</button>
          <button style={secondaryBtn} onClick={() => markPaid("bank_transfer")} disabled={marking}>Mark Paid — Bank Transfer</button>
        </div>
      )}

      <button style={primaryBtn} onClick={() => window.print()}>Print</button>
      <button style={secondaryBtn} onClick={onBack}>Back to Invoices</button>
    </div>
  );
}

function InvoiceForm({ patients, services, onCancel, onSaved }) {
  const [patientId, setPatientId] = useState(patients[0]?.id || "");
  const [items, setItems] = useState([{ catalogId: "", service: "", description: "", cost: "" }]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  function updateItem(i, field, value) {
    setItems(items.map((it, idx) => (idx === i ? { ...it, [field]: value } : it)));
  }

  function pickCatalogItem(i, catalogId) {
    const found = services.find((s) => s.id === catalogId);
    setItems(items.map((it, idx) =>
      idx === i
        ? { ...it, catalogId, service: found ? found.service : it.service, cost: found ? String(found.price) : it.cost }
        : it
    ));
  }

  function addItem() {
    setItems([...items, { catalogId: "", service: "", description: "", cost: "" }]);
  }

  function removeItem(i) {
    setItems(items.filter((_, idx) => idx !== i));
  }

  async function submit() {
    setError("");
    const cleanItems = items
      .filter((it) => it.service && it.cost)
      .map((it) => ({ service: it.service, description: it.description, cost: Number(it.cost) }));

    if (!patientId || cleanItems.length === 0) {
      setError("Select an animal and add at least one line item with a cost.");
      return;
    }

    setSaving(true);
    try {
      await api.post("/api/billing/invoices", { patientId: Number(patientId), items: cleanItems });
      await onSaved();
    } catch (e) {
      setError(e.message || "Failed to create invoice.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>New Invoice</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Pick from the clinic's price list, or add a custom line item</p>
      <ErrorBanner message={error} />

      <div className="form-grid">
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Animal</div>
          <select style={inputStyle} value={patientId} onChange={(e) => setPatientId(e.target.value)}>
            {patients.length === 0 && <option value="">No animal records yet</option>}
            {patients.map((p) => (
              <option key={p.id} value={p.id}>{p.name} ({p.species}{p.ownerName ? ` — ${p.ownerName}` : ""})</option>
            ))}
          </select>
        </div>
      </div>

      <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Line Items</div>
      {items.map((item, i) => (
        <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8, flexWrap: "wrap", alignItems: "center" }}>
          <select style={{ ...inputStyle, flex: "1 1 200px" }} value={item.catalogId} onChange={(e) => pickCatalogItem(i, e.target.value)}>
            <option value="">— Choose from price list —</option>
            {services.map((s) => (
              <option key={s.id} value={s.id}>{s.service} ({money(s.price)})</option>
            ))}
          </select>
          <input style={{ ...inputStyle, flex: "1 1 160px" }} placeholder="Service name" value={item.service} onChange={(e) => updateItem(i, "service", e.target.value)} />
          <input style={{ ...inputStyle, flex: "2 1 200px" }} placeholder="Description (optional)" value={item.description} onChange={(e) => updateItem(i, "description", e.target.value)} />
          <input style={{ ...inputStyle, flex: "0 1 120px" }} type="number" placeholder="Cost (KES)" value={item.cost} onChange={(e) => updateItem(i, "cost", e.target.value)} />
          {items.length > 1 && <Link onClick={() => removeItem(i)}>Remove</Link>}
        </div>
      ))}
      <Link onClick={addItem}>+ Add another item</Link>

      <div style={{ marginTop: 24 }}>
        <button style={primaryBtn} onClick={submit} disabled={saving}>{saving ? "Creating..." : "Create Invoice"}</button>
        <button style={secondaryBtn} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
