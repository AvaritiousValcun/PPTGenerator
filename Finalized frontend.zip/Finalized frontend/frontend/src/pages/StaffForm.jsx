import React, { useState } from "react";
import { Field, ErrorBanner } from "../components/ui";
import { inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";

export default function StaffForm({ onCancel, onSave }) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("vet");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    setError("");
    setSaving(true);
    try {
      await onSave({ firstName, lastName, email, password, role });
    } catch (e) {
      setError(e.message || "Failed to create staff account.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Add Staff Account</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Give a vet, receptionist, or admin access to the system</p>
      <ErrorBanner message={error} />

      <div className="form-grid">
        <Field label="First Name"><input style={inputStyle} value={firstName} onChange={(e) => setFirstName(e.target.value)} /></Field>
        <Field label="Last Name"><input style={inputStyle} value={lastName} onChange={(e) => setLastName(e.target.value)} /></Field>
        <Field label="Email Address"><input type="email" style={inputStyle} value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <Field label="Temporary Password"><input type="password" style={inputStyle} value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} placeholder="At least 8 characters" /></Field>
        <Field label="Role">
          <select style={inputStyle} value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="vet">Vet</option>
            <option value="receptionist">Receptionist</option>
            <option value="admin">Admin</option>
          </select>
        </Field>
      </div>

      <div style={{ marginTop: 16 }}>
        <button style={primaryBtn} onClick={submit} disabled={saving || !firstName || !lastName || !email || !password}>
          {saving ? "Creating..." : "Create Account"}
        </button>
        <button style={secondaryBtn} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
