import React, { useEffect, useState } from "react";
import { Field, Loading, ErrorBanner } from "../components/ui";
import { inputStyle, primaryBtn, secondaryBtn } from "../utils/styles";
import { formatDate } from "../utils/helpers";
import { api } from "../api/client";

export default function MedicalReport({ appointment, canWrite, onBack, onSaved }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api.get(`/api/medical-reports/appointment/${appointment.id}`)
      .then((res) => { if (!cancelled) setReport(res.report); })
      .catch((e) => { if (!cancelled && e.status !== 404) setError(e.message || "Failed to load report."); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [appointment.id]);

  if (loading) return <Loading label="Loading report..." />;

  if (!report || editing) {
    return (
      <ReportForm
        appointment={appointment}
        existing={editing ? report : null}
        onCancel={editing ? () => setEditing(false) : onBack}
        onSaved={async (saved) => { setReport(saved); setEditing(false); await onSaved(); }}
      />
    );
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Medical Report</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>
        {appointment.petName} — {formatDate(report.createdAt)}
        {report.veterinarianName ? ` · Dr. ${report.veterinarianName}` : ""}
      </p>
      <ErrorBanner message={error} />

      <ReadField label="Symptoms" value={report.symptoms} />
      <ReadField label="Diagnosis" value={report.diagnosis} />
      <ReadField label="Treatment Plan" value={report.treatmentPlan} />
      <ReadField label="Prescriptions" value={report.prescriptions} />

      <div style={{ marginTop: 16 }}>
        {canWrite && <button style={primaryBtn} onClick={() => setEditing(true)}>Edit Report</button>}
        <button style={secondaryBtn} onClick={onBack}>Back</button>
      </div>
    </div>
  );
}

function ReadField({ label, value }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: "#64748b", marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 14, color: "#1e293b", whiteSpace: "pre-wrap" }}>{value || "—"}</div>
    </div>
  );
}

function ReportForm({ appointment, existing, onCancel, onSaved }) {
  const [symptoms, setSymptoms] = useState(existing?.symptoms || "");
  const [diagnosis, setDiagnosis] = useState(existing?.diagnosis || "");
  const [treatmentPlan, setTreatmentPlan] = useState(existing?.treatmentPlan || "");
  const [prescriptions, setPrescriptions] = useState(existing?.prescriptions || "");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    setError("");
    if (!symptoms || !diagnosis) {
      setError("Symptoms and diagnosis are required.");
      return;
    }
    setSaving(true);
    try {
      const body = { symptoms, diagnosis, treatmentPlan, prescriptions };
      const res = existing
        ? await api.patch(`/api/medical-reports/${existing.id}`, body)
        : await api.post("/api/medical-reports", { ...body, appointmentId: appointment.id });
      await onSaved(res.report);
    } catch (e) {
      setError(e.message || "Failed to save report.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>{existing ? "Edit Medical Report" : "Write Medical Report"}</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>
        {appointment.petName} ({appointment.petType}) — {appointment.reason}
      </p>
      <ErrorBanner message={error} />

      <Field label="Symptoms">
        <textarea style={{ ...inputStyle, height: 80, resize: "vertical" }} value={symptoms} onChange={(e) => setSymptoms(e.target.value)} placeholder="What the animal presented with" />
      </Field>
      <Field label="Diagnosis">
        <textarea style={{ ...inputStyle, height: 80, resize: "vertical" }} value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} placeholder="Clinical diagnosis" />
      </Field>
      <Field label="Treatment Plan">
        <textarea style={{ ...inputStyle, height: 80, resize: "vertical" }} value={treatmentPlan} onChange={(e) => setTreatmentPlan(e.target.value)} placeholder="What was done / next steps (optional)" />
      </Field>
      <Field label="Prescriptions">
        <textarea style={{ ...inputStyle, height: 80, resize: "vertical" }} value={prescriptions} onChange={(e) => setPrescriptions(e.target.value)} placeholder="Medication, dosage, duration (optional)" />
      </Field>

      {!existing && (
        <p style={{ fontSize: 13, color: "#94a3b8", marginBottom: 12 }}>
          Saving this will mark the appointment as completed.
        </p>
      )}

      <div style={{ marginTop: 8 }}>
        <button style={primaryBtn} onClick={submit} disabled={saving}>{saving ? "Saving..." : existing ? "Save Changes" : "Save Report"}</button>
        <button style={secondaryBtn} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
