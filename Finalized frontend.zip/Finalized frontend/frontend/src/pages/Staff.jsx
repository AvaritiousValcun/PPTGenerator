import React, { useEffect, useState, useCallback } from "react";
import { Th, Td, Link, Loading, ErrorBanner } from "../components/ui";
import { tableStyle, rowStyle, primaryBtn } from "../utils/styles";
import { formatDate } from "../utils/helpers";
import { api } from "../api/client";
import StaffForm from "./StaffForm";

export default function Staff() {
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/api/auth/staff");
      setStaff(res.staff || []);
    } catch (e) {
      setError(e.message || "Failed to load staff.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(form) {
    setError("");
    await api.post("/api/auth/staff", form);
    setShowForm(false);
    await load();
  }

  if (showForm) {
    return <StaffForm onCancel={() => setShowForm(false)} onSave={save} />;
  }

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Staff Accounts</h1>
      <p style={{ color: "#64748b", marginBottom: 24 }}>Vets, receptionists, and admins with access to the system</p>
      <ErrorBanner message={error} />
      <div className="page-toolbar">
        <div />
        <button style={primaryBtn} onClick={() => setShowForm(true)}>+ Add Staff Account</button>
      </div>

      {loading ? <Loading label="Loading staff..." /> : (
        <div className="table-scroll">
          <table style={tableStyle}>
            <thead>
              <tr>
                <Th>Name</Th>
                <Th>Email</Th>
                <Th>Role</Th>
                <Th>Added</Th>
              </tr>
            </thead>
            <tbody>
              {staff.map((s, i) => (
                <tr key={s.id} style={rowStyle(i)}>
                  <Td>{s.firstName} {s.lastName}</Td>
                  <Td>{s.email}</Td>
                  <Td style={{ textTransform: "capitalize" }}>{s.role}</Td>
                  <Td>{formatDate(s.createdAt)}</Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
