// Seed data has been replaced by the live backend API (see src/api/client.js).
// This file now only holds static UI config that isn't user data.
export const NAV_ITEMS = ["Dashboard", "Patients", "Owners", "Appointments", "Billing", "Search"];
